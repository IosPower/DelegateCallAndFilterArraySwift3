//
//  ViewController.swift
//  DelegateCall
//

import UIKit

func delay(_ delay:Double, closure:@escaping ()->()) {
    DispatchQueue.main.asyncAfter(
        deadline: DispatchTime.now() + Double(Int64(delay * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC), execute: closure)
}

class ViewController: UIViewController,UINavigationControllerDelegate, DelegateProtocol {
    
    var firstVC : FirstViewController = FirstViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
         self.navigationController?.delegate = self
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnPresent(_ sender: AnyObject) {
        showColorPicker()
    }
    
    func showColorPicker() {
        firstVC = (self.storyboard?.instantiateViewController(withIdentifier: "FirstViewController") as? FirstViewController)!
        firstVC.delegate = self
        self.present(firstVC, animated: true, completion: nil)
    }
    
    func colorPicker (_ passstring: String){
        print("the delegate method was called")
        delay(0.1) {
            self.dismiss(animated: true, completion: nil)
        }
    }
}

